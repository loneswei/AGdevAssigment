-- Environment Object Info --
housePos = {0,5,-100}
humanPos = {100,0,-100}
lampPos = {50,0,-100}
treePos = {-50,13.5,-100}
carPos = {-100,-4,-100}