-- Laser Blaster Info --
laserMag = 25
laserMaxMag = 25
laserTotal = 100
laserMaxTotal = 100
laserTime = 0.1667

-- Rocket Launcher Info --
rocketMag = 2
rocketMaxMag = 2
rocketTotal = 10
rocketMaxTotal = 10
rocketTime = 3
