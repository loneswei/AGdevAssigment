xgridsize = 100;
zgridsize = 100
xnumgrid = 10;
znumgrid = 10;

highmiddist = 40000;
midlowdist = 160000;