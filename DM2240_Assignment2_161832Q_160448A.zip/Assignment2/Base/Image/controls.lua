-- Keyboard Inputs
moveForward  = "W"
moveBackward = "S"
moveLeft     = "A"
moveRight    = "D"

pickupgun = "G"
dropprimary = "H"
dropsecondary = "T"
reload = "R"

jump = "space"

shootprimary = "LMB"
shootsecondary = "RMB"

