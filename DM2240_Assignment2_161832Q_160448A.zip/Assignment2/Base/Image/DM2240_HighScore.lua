Player1 = 200.1000
Player2 = 100
