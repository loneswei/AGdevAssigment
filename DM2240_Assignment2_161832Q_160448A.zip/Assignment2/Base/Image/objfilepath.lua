-- Object file paths
carlow = "OBJ//LOD//carlow.obj"
carmed = "OBJ//LOD//carmed.obj"
carhigh = "OBJ//LOD//carhigh.obj"

zombiehead = "OBJ//zombiehead.obj"
zombiearm = "OBJ//zombiearm.obj"
zombiebody = "OBJ//zombiebody.obj"
horse = "OBJ//horse.obj"

houseroof = "OBJ//LOD//houseroof.obj"
houseleftwall = "OBJ//LOD//houseleftwall.obj"
housebackwall = "OBJ//LOD//housebackwall.obj"
houserightwall = "OBJ//LOD//houserightwall.obj"
housedoor = "OBJ//LOD//housedoor.obj"

humanlow = "OBJ//LOD//humanlow.obj"
humanmed = "OBJ//LOD//humanmed.obj"
humanhigh = "OBJ//LOD//humanhigh.obj"

lamppostlow = "OBJ//LOD//lamppostlow.obj"
lamppostmed = "OBJ//LOD//lamppostmed.obj"
lampposthigh = "OBJ//LOD//lampposthigh.obj"

treelow = "OBJ//LOD//treelow.obj"
treemed = "OBJ//LOD//treemed.obj"
treehigh = "OBJ//LOD//treehigh.obj"



