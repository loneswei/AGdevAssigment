#include "CameraBase.h"

CameraBase::CameraBase()
{
}

CameraBase::~CameraBase()
{
}